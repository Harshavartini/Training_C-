﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Diagnostics;

//namespace ConsoleApplication1
//{
//    class Program
//    {
//      //  static void Main(string[] args)
//        {

//            Boxing();
//            Noboxing();
//            Console.ReadLine();

//        }
//        public static void Boxing()
//        {
//            Stopwatch obj = new Stopwatch();
//            obj.Start();
//            for (int i = 0; i < 10000; i++)
//            {
//                int i1 = 123;
//                //boxing
//                object j = i1;
//            }
//            obj.Stop();
//            Console.WriteLine(obj.Elapsed.ToString());

//        }
        
//        public static void Noboxing()
//        {
//            Stopwatch obj = new Stopwatch();
//            obj.Start();
//            for (int i = 0; i < 10000; i++)
//            {
//                int i1 = 123;
//                //Noboxing
//              int  j = i1;
//            }
//            obj.Stop();
//            Console.WriteLine(obj.Elapsed.ToString());

//        }
//    }
//}
