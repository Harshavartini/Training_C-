﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace ConsoleApplication1
//{
//    class Garbage
//    {
//        public static void Main(string[] args)
//        {

//            GFG g = new GFG();
//            Console.ReadLine();


//        }
//    }

//    class GFG
//    {
//        public GFG()
//        {
//            Console.WriteLine("Constructor");
//        }
//        ~GFG()
//        {
//            Console.WriteLine("Destructor");
//        }
//    }

//}
