﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Temp
    {
        static void Main(string[] args)
        {
            AutoImplemented a = new AutoImplemented { id=new int[]{1,2,3}, name="HARSHA"};

            Console.WriteLine(a.name);
            foreach (int i in a.id)
                Console.WriteLine(i);
            Console.Read();

        }
    }


    class AutoImplemented
    {
        public int[] id    //Property-array
        {
            get;
            set;
        }
        public string name//Property-string
        {
            get;
            set;
        }
    }
}
