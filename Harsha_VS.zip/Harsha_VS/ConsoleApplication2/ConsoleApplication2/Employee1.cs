﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;


//namespace ConsoleApplication2
//{
//    class Employee1
//    {
//        static void Main(string[] args)
//        {
//           Console.WriteLine("Enter the number of employee details to b filled");
//            int n = Convert.ToInt32(Console.ReadLine());
           
//           List<EmpDetails> list =new List<EmpDetails>();
//           for (int i = 0; i < n; i++)
//               list.Add(new EmpDetails
//              {
//                  empid = Convert.ToInt32(Console.ReadLine()),
//                  fname = Console.ReadLine(),
//                  salary = Convert.ToDouble(Console.ReadLine())
//              });
//              Console.WriteLine("Before Sorting");
//                foreach (var a in list)
//               Console.WriteLine(a.ToString());

//                var query = from e in list orderby e.salary ascending select new { e.empid, e.fname, e.salary };

//               Console.WriteLine("After Sorting");
//               //foreach (var i in query)
//               //{
//               //    Console.WriteLine(i.ToString());
//               //}
//               list = list.OrderBy(w => w.salary).ToList();

                
//                foreach (var a in list)
//                    Console.WriteLine(a.ToString());
//           //var queue = new Queue<EmpDetails>(list);
//           //Console.WriteLine(queue.ToString());





//            Console.Read();
//        }


//    }


//    public class EmpDetails
//    {

//        public int empid
//        {
//            get;
//            set;
//        }
//        public string fname
//        {
//            get;
//            set;
//        }
//        public double salary
//        {
//            get;
//            set;
//        }
//        public override string ToString()
//        {
//            return empid+" "+" "+fname+" "+salary;
//        }
//    }


//}
