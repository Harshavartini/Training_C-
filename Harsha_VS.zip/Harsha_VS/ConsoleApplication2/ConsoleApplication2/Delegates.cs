﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Delegates
    {
        public delegate void calculator(int a, int b);


        public void sum(object a, object b)
        {
            Console.WriteLine("Sum is"+" "+((int)a+(int)b));
        }

        static void Main(string[] args)
        {
            Delegates d = new Delegates();
            calculator c1 = new calculator(d.sum);
            c1(100, 200);
            Console.Read();

        }

        
    }
    class inputs
    {
        object a, b;
        a=(object)Console.ReadLine();

    }
}
