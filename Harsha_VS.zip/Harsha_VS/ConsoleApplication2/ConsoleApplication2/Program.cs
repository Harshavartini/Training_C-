﻿//using system;
//using system.collections.generic;
//using system.linq;
//using system.text;

//namespace consoleapplication2
//{

//    class samplecollection<t>
//    {
        
//    }


//    class program
//    {
//        static void main(string[] args)
//        {



//        }
//    }
//}
